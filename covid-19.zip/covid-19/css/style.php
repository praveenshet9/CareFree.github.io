<style type="text/css" media="screen">
html{
scroll-behavior: smooth;
}
  *{margin: 0; padding: 0; box-sizing: border-box; font-family: 'Muli', sans-serif;}
.row{margin-left: 0!important; margin-right: 0!important;}
  



 .nav_style{ background-color: #4682b4!important; font-weight: bold;

 


  }
.nav_style a{ color: white;
  }

.dropdown-menu{background-color: #4682b4!important; font-weight: bold;

}
.dropdown-menu a{
color: white;
}


/* main header */
.main_header{
  height: 450px;
  width: 100%;
}
.rightside h1{
  font-size: 5rem;
  font-weight: bold;
}
.rightside1 h2{
  font-size: 2rem;
  font-weight: bolder;
}


/* .corona_rot img{
  animation: gocorona 3s linear infinite;
}
@keyframes gocorona{
  0%
{
  transform: rotate(0);
}
100%
{
  transform: rotate(360deg);
}
}
.corona_rot1 img{
animation: gocorona1 3s linear infinite;
}
@keyframes gocorona1{
0%
{
transform: rotate(360deg);
}
100%
{
transform: rotate(0);
}
} */

  
.leftside img{
animation: heartbeat 5s linear infinite;
}
@keyframes heartbeat{
0%
{
  transform: scale(.75) rotate(0);
}
20%
{
  transform: scale(1) rotate(60deg);
}
40%
{
  transform: scale(.75) rotate(120deg);
}
60%
{
  transform: scale(1) rotate(180deg);
}
80%
{
  transform: scale(.75) rotate(240deg);
}
100%
{
  transform: scale(.75) rotate(360deg);
}
}

/* ****************************************corona update***********************
.corona_update h1{
  font-size: 1rem;
  text-align: center;
font-weight: bolder;
}
.corona_update{
  margin: 0 0 30px 0;
  background: #b0c4de;
height: auto;
padding: 50px 0 50px 0; */
/* ****************************************corona update world*********************** */
.update_header{
margin: 0 0 30px 0;
font-size: 2rem;
text-align: center;
font-weight: bolder;
background: #b0c4de;
height:auto;
}
/* ****************************************corona update1 world.php*********************** */
.update1_header{
margin: 0 0 30px 0;
font-size: 2rem;
text-align: center;
font-weight: bolder;
background: #b0c4de;
height:auto;
}
/* ****************** about section ************************** */
.sub_section{
background-color:#fbfafd;
}
.section_header h1{
font-weight: bolder;
}

.question h1{
font-weight: bold;
color: #ff0000;
}
.question p{
font-weight: bold;
}
.about_res{margin-left: 0!important;}
/* ************************************** symptoms sectin ************************* */
.text-center{
font-weight: bold;
}
/* ************************************** prevention sectin ************************* */
.container p{
font-weight: bold;
}
/* *********************************** contactus sectin ************************* */
#contactid{
font-weight: bold;
}
/* ************************************** footer sectin ************************* */
.footer_s{
background-color: #4682b4!important;
margin-bottom: 0!important;
}
.footer_s p{
margin-bottom: 0!important;
}
/* ************************************** scroll up ************************* */
#myBtn {
display: none;
position: fixed;
bottom: 30px;
right: 40px;
z-index: 99;
border: none;
outline: none;
background-color: #39ff14;
color: white;
cursor: pointer;
padding: 10px;
border-radius: 10px;
}
#myBtn:hover{
background: #060606;
}
/* ************************************** Responsive ************************* */
@media (max-width:768px){
.main_header{height:700px; text-align: center;}
.main_header h1{
text-align: center;
padding: 0;
width: 100%;
font-size: 30px;
}
.main_header h2{
text-align: center;
padding: 0;
width: 100%;
font-size: 30px;
}
}







































</style>