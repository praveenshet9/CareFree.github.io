<?php
$data=file_get_contents('https://api.covid19api.com/summary');
$coronadata=json_decode($data);


echo "<pre>";
print_r($coronadata)

?>







<?php
$data=file_get_contents(https://api.covid19india.org/csv/);
$coronadata=json_decode($data);


echo "<pre>";
print_r($coronadata)

?>





 <?php
       $data=file_get_contents('https://api.covid19india.org/data.json');
       $coronadata=json_decode($data,true);


           
           

           
     






     ?>










  	</table>
  	
  </div>
</section>